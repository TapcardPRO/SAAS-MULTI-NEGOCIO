import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { ObjectId } from "mongodb";
import { getDb } from "@/lib/db";
import { verifySessionToken } from "@/lib/auth";

type RouteProps = {
  params: Promise<{
    slug: string;
  }>;
};

async function getAuthenticatedBusiness(slug: string) {
  const cookieStore = await cookies();

  const token =
    cookieStore.get("saas_session")?.value;

  if (!token) {
    return {
      ok: false as const,
      status: 401,
      message: "Usuário não autenticado",
    };
  }

  const session =
    await verifySessionToken(token);

  if (!session?.userId) {
    return {
      ok: false as const,
      status: 401,
      message: "Sessão inválida",
    };
  }

  const userId = session.userId;

  if (!ObjectId.isValid(userId)) {
    return {
      ok: false as const,
      status: 401,
      message: "Sessão inválida",
    };
  }

  const db = await getDb();

  const user = await db
    .collection("users")
    .findOne({
      _id: new ObjectId(userId),
    });

  if (!user) {
    return {
      ok: false as const,
      status: 401,
      message: "Usuário não encontrado",
    };
  }

  if (!user.businessId) {
    return {
      ok: false as const,
      status: 403,
      message:
        "Usuário não possui empresa vinculada",
    };
  }

  const businessId = String(
    user.businessId
  );

  if (!ObjectId.isValid(businessId)) {
    return {
      ok: false as const,
      status: 403,
      message: "Empresa inválida",
    };
  }

  const business = await db
    .collection("businesses")
    .findOne({
      _id: new ObjectId(businessId),
    });

  if (!business) {
    return {
      ok: false as const,
      status: 404,
      message: "Empresa não encontrada",
    };
  }

  if (business.slug !== slug) {
    return {
      ok: false as const,
      status: 403,
      message:
        "Você não tem permissão para acessar esta empresa",
    };
  }

  return {
    ok: true as const,
    db,
    business,
    user,
  };
}

export async function GET(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const services = await auth.db
      .collection("services")
      .find({
        businessSlug: slug,
      })
      .sort({
        order: 1,
        createdAt: 1,
      })
      .toArray();

    return NextResponse.json({
      ok: true,
      services,
    });
  } catch (error) {
    console.error(
      "Erro ao buscar serviços:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao buscar serviços",
      },
      {
        status: 500,
      }
    );
  }
}

export async function POST(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const body = await request.json();

    const name = String(
      body.name || ""
    ).trim();

    if (!name) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Informe o nome do serviço",
        },
        {
          status: 400,
        }
      );
    }

    const price = Number(
      body.price || 0
    );

    const duration = Number(
      body.duration || 0
    );

    if (
      !Number.isFinite(price) ||
      price < 0
    ) {
      return NextResponse.json(
        {
          ok: false,
          message: "Preço inválido",
        },
        {
          status: 400,
        }
      );
    }

    if (
      !Number.isFinite(duration) ||
      duration < 0
    ) {
      return NextResponse.json(
        {
          ok: false,
          message: "Duração inválida",
        },
        {
          status: 400,
        }
      );
    }

    const totalServices =
      await auth.db
        .collection("services")
        .countDocuments({
          businessSlug: slug,
        });

    const service = {
      businessSlug: slug,

      name,

      description: String(
        body.description || ""
      ).trim(),

      price,

      duration,

      photoUrl: String(
        body.photoUrl || ""
      ).trim(),

      active:
        body.active !== false,

      order:
        totalServices + 1,

      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result =
      await auth.db
        .collection("services")
        .insertOne(service);

    return NextResponse.json({
      ok: true,
      message:
        "Serviço criado com sucesso",

      service: {
        _id:
          result.insertedId.toString(),
        ...service,
      },
    });
  } catch (error) {
    console.error(
      "Erro ao criar serviço:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao criar serviço",
      },
      {
        status: 500,
      }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const body = await request.json();

    const id = String(
      body.id || ""
    );

    if (!ObjectId.isValid(id)) {
      return NextResponse.json(
        {
          ok: false,
          message: "Serviço inválido",
        },
        {
          status: 400,
        }
      );
    }

    const updateData: Record<
      string,
      unknown
    > = {
      updatedAt: new Date(),
    };

    if (
      body.name !== undefined
    ) {
      const name = String(
        body.name
      ).trim();

      if (!name) {
        return NextResponse.json(
          {
            ok: false,
            message:
              "Informe o nome do serviço",
          },
          {
            status: 400,
          }
        );
      }

      updateData.name = name;
    }

    if (
      body.description !== undefined
    ) {
      updateData.description =
        String(
          body.description || ""
        ).trim();
    }

    if (
      body.price !== undefined
    ) {
      const price = Number(
        body.price
      );

      if (
        !Number.isFinite(price) ||
        price < 0
      ) {
        return NextResponse.json(
          {
            ok: false,
            message:
              "Preço inválido",
          },
          {
            status: 400,
          }
        );
      }

      updateData.price = price;
    }

    if (
      body.duration !== undefined
    ) {
      const duration = Number(
        body.duration
      );

      if (
        !Number.isFinite(duration) ||
        duration < 0
      ) {
        return NextResponse.json(
          {
            ok: false,
            message:
              "Duração inválida",
          },
          {
            status: 400,
          }
        );
      }

      updateData.duration =
        duration;
    }

    if (
      body.photoUrl !== undefined
    ) {
      updateData.photoUrl =
        String(
          body.photoUrl || ""
        ).trim();
    }

    if (
      body.active !== undefined
    ) {
      updateData.active =
        Boolean(body.active);
    }

    if (
      body.order !== undefined
    ) {
      const order = Number(
        body.order
      );

      if (
        Number.isFinite(order)
      ) {
        updateData.order = order;
      }
    }

    const objectId =
      new ObjectId(id);

    const result =
      await auth.db
        .collection("services")
        .updateOne(
          {
            _id: objectId,
            businessSlug: slug,
          },
          {
            $set: updateData,
          }
        );

    if (
      result.matchedCount === 0
    ) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Serviço não encontrado",
        },
        {
          status: 404,
        }
      );
    }

    const service =
      await auth.db
        .collection("services")
        .findOne({
          _id: objectId,
          businessSlug: slug,
        });

    return NextResponse.json({
      ok: true,
      message:
        "Serviço atualizado com sucesso",
      service,
    });
  } catch (error) {
    console.error(
      "Erro ao atualizar serviço:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao atualizar serviço",
      },
      {
        status: 500,
      }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const url =
      new URL(request.url);

    const id =
      url.searchParams.get("id");

    if (
      !id ||
      !ObjectId.isValid(id)
    ) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Serviço inválido",
        },
        {
          status: 400,
        }
      );
    }

    const result =
      await auth.db
        .collection("services")
        .deleteOne({
          _id: new ObjectId(id),
          businessSlug: slug,
        });

    if (
      result.deletedCount === 0
    ) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Serviço não encontrado",
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json({
      ok: true,
      message:
        "Serviço excluído com sucesso",
    });
  } catch (error) {
    console.error(
      "Erro ao excluir serviço:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao excluir serviço",
      },
      {
        status: 500,
      }
    );
  }
}