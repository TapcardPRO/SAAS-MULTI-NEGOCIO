import { NextResponse } from "next/server";

export async function POST() {
  const response = NextResponse.json({
    ok: true,
    message: "Logout realizado com sucesso",
  });

  response.cookies.set(
    "saas_user_id",
    "",
    {
      httpOnly: true,
      sameSite: "lax",
      secure:
        process.env.NODE_ENV === "production",
      path: "/",
      expires: new Date(0),
    }
  );

  return response;
}