import { NextResponse } from "next/server";
import { cookies } from "next/headers";
import { ObjectId } from "mongodb";
import { getDb } from "@/lib/db";

type RouteProps = {
  params: Promise<{
    slug: string;
  }>;
};

async function getAuthenticatedBusiness(slug: string) {
  const cookieStore = await cookies();

  const userId =
    cookieStore.get("saas_user_id")?.value;

  if (!userId || !ObjectId.isValid(userId)) {
    return {
      ok: false as const,
      status: 401,
      message: "Usuário não autenticado",
    };
  }

  const db = await getDb();

  const user = await db
    .collection("users")
    .findOne({
      _id: new ObjectId(userId),
    });

  if (!user) {
    return {
      ok: false as const,
      status: 401,
      message: "Usuário não encontrado",
    };
  }

  if (!user.businessId) {
    return {
      ok: false as const,
      status: 403,
      message:
        "Usuário não possui empresa vinculada",
    };
  }

  const businessId = String(
    user.businessId
  );

  if (!ObjectId.isValid(businessId)) {
    return {
      ok: false as const,
      status: 403,
      message: "Empresa inválida",
    };
  }

  const business = await db
    .collection("businesses")
    .findOne({
      _id: new ObjectId(businessId),
    });

  if (!business) {
    return {
      ok: false as const,
      status: 404,
      message: "Empresa não encontrada",
    };
  }

  if (business.slug !== slug) {
    return {
      ok: false as const,
      status: 403,
      message:
        "Você não tem permissão para acessar esta empresa",
    };
  }

  return {
    ok: true as const,
    db,
    business,
    user,
  };
}

export async function GET(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const professionals =
      await auth.db
        .collection("professionals")
        .find({
          businessSlug: slug,
        })
        .sort({
          order: 1,
          createdAt: 1,
        })
        .toArray();

    return NextResponse.json({
      ok: true,
      professionals,
    });
  } catch (error) {
    console.error(
      "Erro ao buscar profissionais:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao buscar profissionais",
      },
      {
        status: 500,
      }
    );
  }
}

export async function POST(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const body = await request.json();

    const name = String(
      body.name || ""
    ).trim();

    if (!name) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Informe o nome do profissional",
        },
        {
          status: 400,
        }
      );
    }

    const totalProfessionals =
      await auth.db
        .collection("professionals")
        .countDocuments({
          businessSlug: slug,
        });

    const professional = {
      businessSlug: slug,

      name,

      role: String(
        body.role || ""
      ).trim(),

      description: String(
        body.description || ""
      ).trim(),

      photoUrl: String(
        body.photoUrl || ""
      ).trim(),

      active:
        body.active !== false,

      order:
        totalProfessionals + 1,

      createdAt: new Date(),

      updatedAt: new Date(),
    };

    const result =
      await auth.db
        .collection("professionals")
        .insertOne(professional);

    return NextResponse.json({
      ok: true,
      message:
        "Profissional criado com sucesso",

      professional: {
        _id:
          result.insertedId.toString(),
        ...professional,
      },
    });
  } catch (error) {
    console.error(
      "Erro ao criar profissional:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao criar profissional",
      },
      {
        status: 500,
      }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const body = await request.json();

    const id = String(
      body.id || ""
    );

    if (!ObjectId.isValid(id)) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Profissional inválido",
        },
        {
          status: 400,
        }
      );
    }

    const updateData: Record<
      string,
      unknown
    > = {
      updatedAt: new Date(),
    };

    if (
      body.name !== undefined
    ) {
      const name = String(
        body.name
      ).trim();

      if (!name) {
        return NextResponse.json(
          {
            ok: false,
            message:
              "Informe o nome do profissional",
          },
          {
            status: 400,
          }
        );
      }

      updateData.name = name;
    }

    if (
      body.role !== undefined
    ) {
      updateData.role =
        String(
          body.role || ""
        ).trim();
    }

    if (
      body.description !== undefined
    ) {
      updateData.description =
        String(
          body.description || ""
        ).trim();
    }

    if (
      body.photoUrl !== undefined
    ) {
      updateData.photoUrl =
        String(
          body.photoUrl || ""
        ).trim();
    }

    if (
      body.active !== undefined
    ) {
      updateData.active =
        Boolean(body.active);
    }

    if (
      body.order !== undefined
    ) {
      const order = Number(
        body.order
      );

      if (
        Number.isFinite(order)
      ) {
        updateData.order = order;
      }
    }

    const objectId =
      new ObjectId(id);

    const result =
      await auth.db
        .collection("professionals")
        .updateOne(
          {
            _id: objectId,
            businessSlug: slug,
          },
          {
            $set: updateData,
          }
        );

    if (
      result.matchedCount === 0
    ) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Profissional não encontrado",
        },
        {
          status: 404,
        }
      );
    }

    const professional =
      await auth.db
        .collection("professionals")
        .findOne({
          _id: objectId,
          businessSlug: slug,
        });

    return NextResponse.json({
      ok: true,
      message:
        "Profissional atualizado com sucesso",
      professional,
    });
  } catch (error) {
    console.error(
      "Erro ao atualizar profissional:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao atualizar profissional",
      },
      {
        status: 500,
      }
    );
  }
}

export async function DELETE(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;

    const auth =
      await getAuthenticatedBusiness(slug);

    if (!auth.ok) {
      return NextResponse.json(
        {
          ok: false,
          message: auth.message,
        },
        {
          status: auth.status,
        }
      );
    }

    const url =
      new URL(request.url);

    const id =
      url.searchParams.get("id");

    if (
      !id ||
      !ObjectId.isValid(id)
    ) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Profissional inválido",
        },
        {
          status: 400,
        }
      );
    }

    const result =
      await auth.db
        .collection("professionals")
        .deleteOne({
          _id: new ObjectId(id),
          businessSlug: slug,
        });

    if (
      result.deletedCount === 0
    ) {
      return NextResponse.json(
        {
          ok: false,
          message:
            "Profissional não encontrado",
        },
        {
          status: 404,
        }
      );
    }

    return NextResponse.json({
      ok: true,
      message:
        "Profissional excluído com sucesso",
    });
  } catch (error) {
    console.error(
      "Erro ao excluir profissional:",
      error
    );

    return NextResponse.json(
      {
        ok: false,
        message:
          "Erro ao excluir profissional",
      },
      {
        status: 500,
      }
    );
  }
}