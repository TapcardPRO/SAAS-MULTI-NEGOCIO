import { ReactNode } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ObjectId } from "mongodb";

import { getDb } from "@/lib/db";
import { verifySessionToken } from "@/lib/auth";

export default async function DashboardLayout({
  children,
}: {
  children: ReactNode;
}) {
  const cookieStore = await cookies();

  const token =
    cookieStore.get("saas_session")?.value;

  /*
   * Sem sessão
   */
  if (!token) {
    redirect("/login");
  }

  const session =
    await verifySessionToken(token);

  /*
   * Sessão inválida
   */
  if (
    !session?.userId ||
    !ObjectId.isValid(session.userId)
  ) {
    redirect("/login");
  }

  const db = await getDb();

  const user = await db
    .collection("users")
    .findOne({
      _id: new ObjectId(session.userId),
    });

  /*
   * Usuário não existe
   */
  if (!user) {
    redirect("/login");
  }

  /*
   * Super Admin não entra
   * no dashboard de cliente.
   */
  if (user.role === "superadmin") {
    redirect("/admin");
  }

  /*
   * Usuário bloqueado
   */
  if (user.active === false) {
    redirect("/login?blocked=1");
  }

  /*
   * Precisa estar vinculado
   * a uma empresa.
   */
  if (!user.businessId) {
    redirect("/login");
  }

  const businessId = String(
    user.businessId
  );

  if (!ObjectId.isValid(businessId)) {
    redirect("/login");
  }

  const business = await db
    .collection("businesses")
    .findOne({
      _id: new ObjectId(businessId),
    });

  /*
   * Empresa não existe
   */
  if (!business) {
    redirect("/login");
  }

  /*
   * EMPRESA BLOQUEADA
   *
   * Esse é o ponto principal.
   * Mesmo que o cliente já tivesse
   * feito login anteriormente,
   * ele não consegue carregar
   * nenhuma página dentro de /dashboard.
   */
  if (business.active === false) {
    redirect("/login?blocked=1");
  }

  return <>{children}</>;
}