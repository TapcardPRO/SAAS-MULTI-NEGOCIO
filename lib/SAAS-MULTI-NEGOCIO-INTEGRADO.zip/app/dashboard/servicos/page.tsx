"use client";

import { FormEvent, useEffect, useState } from "react";

type Service = {
  _id: string;
  name: string;
  description: string;
  price: number;
  duration: number;
  photoUrl: string;
  active: boolean;
  order: number;
};

type ServiceForm = {
  name: string;
  description: string;
  price: string;
  duration: string;
  photoUrl: string;
  active: boolean;
};

const SLUG = "engenheiros-do-corte";

const emptyForm: ServiceForm = {
  name: "",
  description: "",
  price: "",
  duration: "",
  photoUrl: "",
  active: true,
};

export default function ServicosPage() {
  const [services, setServices] = useState<Service[]>([]);
  const [form, setForm] = useState<ServiceForm>(emptyForm);
  const [editingId, setEditingId] = useState<string | null>(null);

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    loadServices();
  }, []);

  async function loadServices() {
    try {
      setLoading(true);

      const response = await fetch(`/api/services/${SLUG}`);
      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Erro ao carregar serviços");
        return;
      }

      setServices(data.services || []);
    } catch (error) {
      console.error(error);
      setMessage("Erro ao carregar serviços");
    } finally {
      setLoading(false);
    }
  }

  async function uploadImage(file: File): Promise<string> {
    const uploadData = new FormData();

    uploadData.append("file", file);
    uploadData.append(
      "folder",
      `saas-multi-negocio/${SLUG}/servicos`
    );

    const response = await fetch("/api/upload", {
      method: "POST",
      body: uploadData,
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || "Erro ao enviar imagem");
    }

    return data.url;
  }

  async function handlePhotoUpload(file: File | null) {
    if (!file) return;

    try {
      setUploading(true);
      setMessage("");

      const url = await uploadImage(file);

      setForm((current) => ({
        ...current,
        photoUrl: url,
      }));

      setMessage("Foto enviada com sucesso.");
    } catch (error) {
      console.error(error);

      setMessage(
        error instanceof Error
          ? error.message
          : "Erro ao enviar foto"
      );
    } finally {
      setUploading(false);
    }
  }

  async function saveService(event: FormEvent) {
    event.preventDefault();

    if (!form.name.trim()) {
      setMessage("Informe o nome do serviço.");
      return;
    }

    try {
      setSaving(true);
      setMessage("");

      const body = {
        ...(editingId ? { id: editingId } : {}),

        name: form.name,
        description: form.description,

        price: Number(form.price.replace(",", ".")),

        duration: Number(form.duration),

        photoUrl: form.photoUrl,
        active: form.active,
      };

      const response = await fetch(`/api/services/${SLUG}`, {
        method: editingId ? "PUT" : "POST",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify(body),
      });

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Erro ao salvar serviço");
        return;
      }

      setMessage(
        editingId
          ? "Serviço atualizado com sucesso!"
          : "Serviço criado com sucesso!"
      );

      cancelEdit();
      await loadServices();
    } catch (error) {
      console.error(error);
      setMessage("Erro ao salvar serviço");
    } finally {
      setSaving(false);
    }
  }

  function editService(service: Service) {
    setEditingId(service._id);

    setForm({
      name: service.name || "",
      description: service.description || "",
      price: String(service.price ?? ""),
      duration: String(service.duration ?? ""),
      photoUrl: service.photoUrl || "",
      active: service.active !== false,
    });

    window.scrollTo({
      top: 0,
      behavior: "smooth",
    });
  }

  function cancelEdit() {
    setEditingId(null);
    setForm(emptyForm);
  }

  async function toggleActive(service: Service) {
    try {
      setMessage("");

      const response = await fetch(`/api/services/${SLUG}`, {
        method: "PUT",

        headers: {
          "Content-Type": "application/json",
        },

        body: JSON.stringify({
          id: service._id,
          active: !service.active,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Erro ao alterar serviço");
        return;
      }

      await loadServices();
    } catch (error) {
      console.error(error);
      setMessage("Erro ao alterar status do serviço");
    }
  }

  async function deleteService(service: Service) {
    const confirmed = window.confirm(
      `Deseja realmente excluir "${service.name}"?`
    );

    if (!confirmed) return;

    try {
      setMessage("");

      const response = await fetch(
        `/api/services/${SLUG}?id=${service._id}`,
        {
          method: "DELETE",
        }
      );

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Erro ao excluir serviço");
        return;
      }

      if (editingId === service._id) {
        cancelEdit();
      }

      setMessage("Serviço excluído.");
      await loadServices();
    } catch (error) {
      console.error(error);
      setMessage("Erro ao excluir serviço");
    }
  }

  return (
    <main className="min-h-screen bg-zinc-950 text-white">
      <div className="mx-auto max-w-7xl px-6 py-10">
        <div className="mb-10">
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-400">
            Catálogo
          </p>

          <h1 className="mt-2 text-3xl font-bold">
            Serviços
          </h1>

          <p className="mt-2 text-zinc-400">
            Cadastre e gerencie os serviços exibidos para seus clientes.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-[420px_1fr]">
          <form
            onSubmit={saveService}
            className="h-fit space-y-5 rounded-2xl border border-white/10 bg-white/5 p-6 lg:sticky lg:top-6"
          >
            <div>
              <h2 className="text-xl font-semibold">
                {editingId ? "Editar serviço" : "Novo serviço"}
              </h2>

              <p className="mt-1 text-sm text-zinc-500">
                Preencha as informações do serviço.
              </p>
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Foto do serviço
              </label>

              <label className="flex cursor-pointer items-center justify-center rounded-xl border border-dashed border-white/20 bg-zinc-900 px-5 py-5 text-center transition hover:border-emerald-500">
                <span>
                  {uploading
                    ? "Enviando foto..."
                    : form.photoUrl
                      ? "Trocar foto"
                      : "Escolher foto"}
                </span>

                <input
                  type="file"
                  accept="image/*"
                  disabled={uploading}
                  onChange={(e) =>
                    handlePhotoUpload(e.target.files?.[0] || null)
                  }
                  className="hidden"
                />
              </label>

              {form.photoUrl ? (
                <div className="mt-4 rounded-2xl border border-white/10 bg-zinc-900 p-3">
                  <img
                    src={form.photoUrl}
                    alt="Foto do serviço"
                    className="h-48 w-full rounded-xl object-cover"
                  />

                  <button
                    type="button"
                    onClick={() =>
                      setForm((current) => ({
                        ...current,
                        photoUrl: "",
                      }))
                    }
                    className="mt-3 w-full rounded-lg border border-red-500/30 px-4 py-2 text-sm text-red-400 hover:bg-red-500/10"
                  >
                    Remover foto
                  </button>
                </div>
              ) : null}
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Nome do serviço
              </label>

              <input
                value={form.name}
                onChange={(e) =>
                  setForm((current) => ({
                    ...current,
                    name: e.target.value,
                  }))
                }
                placeholder="Ex: Corte Tradicional"
                className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Descrição
              </label>

              <textarea
                value={form.description}
                onChange={(e) =>
                  setForm((current) => ({
                    ...current,
                    description: e.target.value,
                  }))
                }
                rows={4}
                placeholder="Ex: Corte personalizado de acordo com seu estilo."
                className="w-full resize-none rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="mb-2 block text-sm text-zinc-400">
                  Valor
                </label>

                <div className="flex overflow-hidden rounded-xl border border-white/10 bg-zinc-900 focus-within:border-emerald-500">
                  <span className="flex items-center border-r border-white/10 px-3 text-sm text-zinc-500">
                    R$
                  </span>

                  <input
                    value={form.price}
                    onChange={(e) =>
                      setForm((current) => ({
                        ...current,
                        price: e.target.value,
                      }))
                    }
                    inputMode="decimal"
                    placeholder="35,00"
                    className="min-w-0 flex-1 bg-transparent px-3 py-3 outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="mb-2 block text-sm text-zinc-400">
                  Duração
                </label>

                <div className="flex overflow-hidden rounded-xl border border-white/10 bg-zinc-900 focus-within:border-emerald-500">
                  <input
                    type="number"
                    min="0"
                    value={form.duration}
                    onChange={(e) =>
                      setForm((current) => ({
                        ...current,
                        duration: e.target.value,
                      }))
                    }
                    placeholder="40"
                    className="min-w-0 flex-1 bg-transparent px-3 py-3 outline-none"
                  />

                  <span className="flex items-center border-l border-white/10 px-3 text-sm text-zinc-500">
                    min
                  </span>
                </div>
              </div>
            </div>

            <label className="flex cursor-pointer items-center justify-between rounded-xl border border-white/10 bg-zinc-900 px-4 py-4">
              <div>
                <p className="font-medium">
                  Serviço ativo
                </p>

                <p className="mt-1 text-xs text-zinc-500">
                  Serviços desativados não aparecerão para os clientes.
                </p>
              </div>

              <input
                type="checkbox"
                checked={form.active}
                onChange={(e) =>
                  setForm((current) => ({
                    ...current,
                    active: e.target.checked,
                  }))
                }
                className="h-5 w-5"
              />
            </label>

            <button
              type="submit"
              disabled={saving || uploading}
              className="w-full rounded-xl bg-emerald-500 px-5 py-3 font-semibold text-zinc-950 transition hover:bg-emerald-400 disabled:opacity-50"
            >
              {saving
                ? "Salvando..."
                : editingId
                  ? "Salvar alterações"
                  : "Adicionar serviço"}
            </button>

            {editingId ? (
              <button
                type="button"
                onClick={cancelEdit}
                className="w-full rounded-xl border border-white/10 px-5 py-3 font-medium text-zinc-300 transition hover:bg-white/5"
              >
                Cancelar edição
              </button>
            ) : null}

            {message ? (
              <div className="rounded-xl border border-white/10 bg-white/5 p-4 text-sm">
                {message}
              </div>
            ) : null}
          </form>

          <section>
            <div className="mb-5">
              <h2 className="text-xl font-semibold">
                Seus serviços
              </h2>

              <p className="mt-1 text-sm text-zinc-500">
                {services.length} serviço(s) cadastrado(s)
              </p>
            </div>

            {loading ? (
              <div className="rounded-2xl border border-white/10 bg-white/5 p-8 text-zinc-400">
                Carregando serviços...
              </div>
            ) : services.length === 0 ? (
              <div className="rounded-2xl border border-dashed border-white/20 p-10 text-center">
                <p className="font-medium">
                  Nenhum serviço cadastrado.
                </p>

                <p className="mt-2 text-sm text-zinc-500">
                  Cadastre seu primeiro serviço no formulário ao lado.
                </p>
              </div>
            ) : (
              <div className="grid gap-5 sm:grid-cols-2">
                {services.map((service) => (
                  <div
                    key={service._id}
                    className={`overflow-hidden rounded-2xl border bg-white/5 ${
                      service.active
                        ? "border-white/10"
                        : "border-red-500/20 opacity-60"
                    }`}
                  >
                    {service.photoUrl ? (
                      <img
                        src={service.photoUrl}
                        alt={service.name}
                        className="h-52 w-full object-cover"
                      />
                    ) : (
                      <div className="flex h-52 items-center justify-center bg-zinc-900 text-sm text-zinc-600">
                        Sem foto
                      </div>
                    )}

                    <div className="p-5">
                      <div className="flex items-start justify-between gap-4">
                        <div className="min-w-0">
                          <h3 className="truncate text-xl font-semibold">
                            {service.name}
                          </h3>

                          <p
                            className={`mt-1 text-xs font-semibold uppercase tracking-wider ${
                              service.active
                                ? "text-emerald-400"
                                : "text-red-400"
                            }`}
                          >
                            {service.active
                              ? "Ativo"
                              : "Desativado"}
                          </p>
                        </div>

                        <p className="shrink-0 text-lg font-bold text-emerald-400">
                          {formatPrice(service.price)}
                        </p>
                      </div>

                      {service.description ? (
                        <p className="mt-4 line-clamp-3 text-sm leading-6 text-zinc-400">
                          {service.description}
                        </p>
                      ) : null}

                      <div className="mt-5 flex items-center justify-between border-t border-white/10 pt-4 text-sm">
                        <span className="text-zinc-500">
                          Duração
                        </span>

                        <span className="font-medium">
                          {service.duration} min
                        </span>
                      </div>

                      <div className="mt-5 grid grid-cols-2 gap-2">
                        <button
                          type="button"
                          onClick={() =>
                            editService(service)
                          }
                          className="rounded-xl border border-white/10 px-3 py-2 text-sm font-medium transition hover:bg-white/5"
                        >
                          Editar
                        </button>

                        <button
                          type="button"
                          onClick={() =>
                            toggleActive(service)
                          }
                          className="rounded-xl border border-white/10 px-3 py-2 text-sm font-medium transition hover:bg-white/5"
                        >
                          {service.active
                            ? "Desativar"
                            : "Ativar"}
                        </button>
                      </div>

                      <button
                        type="button"
                        onClick={() =>
                          deleteService(service)
                        }
                        className="mt-2 w-full rounded-xl border border-red-500/30 px-3 py-2 text-sm font-medium text-red-400 transition hover:bg-red-500/10"
                      >
                        Excluir
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </section>
        </div>
      </div>
    </main>
  );
}

function formatPrice(price: number) {
  return new Intl.NumberFormat("pt-BR", {
    style: "currency",
    currency: "BRL",
  }).format(price || 0);
}