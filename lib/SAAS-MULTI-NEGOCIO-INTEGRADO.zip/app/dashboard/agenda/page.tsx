"use client";
import { useEffect, useMemo, useState } from "react";

type Appointment = { _id: string; clientName: string; clientPhone: string; serviceName: string; professionalName: string; date: string; time: string; price: number; status: string; notes?: string };

export default function AgendaPage() {
  const [date, setDate] = useState(today());
  const [items, setItems] = useState<Appointment[]>([]);
  const [loading, setLoading] = useState(true);
  const [message, setMessage] = useState("");

  async function load() {
    try {
      setLoading(true); setMessage("");
      const response = await fetch(`/api/dashboard/appointments?date=${date}`, { cache: "no-store" });
      const data = await response.json();
      if (!response.ok) return setMessage(data.message || "Erro ao carregar agenda");
      setItems(data.appointments || []);
    } catch { setMessage("Erro ao carregar agenda"); } finally { setLoading(false); }
  }
  useEffect(() => { load(); }, [date]);

  async function changeStatus(id: string, status: string) {
    const response = await fetch(`/api/dashboard/appointments/${id}`, { method: "PUT", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ status }) });
    const data = await response.json();
    if (!response.ok) return setMessage(data.message || "Erro ao atualizar");
    await load();
  }

  const stats = useMemo(() => ({ total: items.length, pending: items.filter((x) => x.status === "pendente").length, confirmed: items.filter((x) => x.status === "confirmado").length, completed: items.filter((x) => x.status === "concluido").length }), [items]);

  return <main className="min-h-screen bg-zinc-950 text-white"><div className="mx-auto max-w-7xl px-6 py-10"><div className="flex flex-col gap-5 sm:flex-row sm:items-end sm:justify-between"><div><p className="text-sm font-bold uppercase tracking-widest text-emerald-400">Painel da empresa</p><h1 className="mt-2 text-3xl font-bold">Agenda</h1><p className="mt-2 text-zinc-400">Agendamentos públicos e criados pelo painel aparecem aqui.</p></div><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className="rounded-xl border border-white/10 bg-zinc-900 px-4 py-3" /></div><div className="mt-8 grid gap-4 sm:grid-cols-4"><Stat label="Total" value={stats.total}/><Stat label="Pendentes" value={stats.pending}/><Stat label="Confirmados" value={stats.confirmed}/><Stat label="Concluídos" value={stats.completed}/></div>{message ? <p className="mt-6 rounded-xl border border-red-500/20 bg-red-500/5 p-4 text-red-300">{message}</p> : null}<div className="mt-8 space-y-4">{loading ? <Empty text="Carregando agenda..." /> : items.length === 0 ? <Empty text="Nenhum agendamento nessa data." /> : items.map((a) => <article key={a._id} className="rounded-2xl border border-white/10 bg-white/5 p-5"><div className="flex flex-col gap-5 lg:flex-row lg:items-center lg:justify-between"><div className="flex gap-5"><div className="text-2xl font-bold text-emerald-400">{a.time}</div><div><div className="flex flex-wrap items-center gap-2"><h2 className="font-bold">{a.clientName}</h2><Badge status={a.status}/></div><p className="mt-1 text-sm text-zinc-400">{a.serviceName} • {a.professionalName}</p><p className="mt-1 text-sm text-zinc-500">{a.clientPhone} • {money(a.price)}</p>{a.notes ? <p className="mt-2 text-sm text-zinc-500">Obs: {a.notes}</p> : null}</div></div><div className="flex flex-wrap gap-2">{a.status === "pendente" ? <Action text="Confirmar" onClick={() => changeStatus(a._id, "confirmado")} /> : null}{a.status !== "concluido" && a.status !== "cancelado" && a.status !== "faltou" ? <Action text="Concluir" onClick={() => changeStatus(a._id, "concluido")} /> : null}{a.status !== "concluido" && a.status !== "cancelado" ? <Action text="Faltou" onClick={() => changeStatus(a._id, "faltou")} secondary /> : null}{a.status !== "concluido" && a.status !== "cancelado" ? <Action text="Cancelar" onClick={() => changeStatus(a._id, "cancelado")} danger /> : null}</div></div></article>)}</div></div></main>;
}
function Stat({label,value}:{label:string;value:number}){return <div className="rounded-2xl border border-white/10 bg-white/5 p-5"><p className="text-sm text-zinc-500">{label}</p><p className="mt-2 text-3xl font-bold">{value}</p></div>}
function Empty({text}:{text:string}){return <div className="rounded-2xl border border-dashed border-white/10 p-10 text-center text-zinc-500">{text}</div>}
function Badge({status}:{status:string}){const map:Record<string,string>={pendente:"Pendente",confirmado:"Confirmado",concluido:"Concluído",cancelado:"Cancelado",faltou:"Faltou",em_atendimento:"Em atendimento"};return <span className="rounded-full bg-zinc-800 px-2 py-1 text-xs font-semibold">{map[status]||status}</span>}
function Action({text,onClick,secondary,danger}:{text:string;onClick:()=>void;secondary?:boolean;danger?:boolean}){return <button type="button" onClick={onClick} className={`rounded-lg px-3 py-2 text-sm font-semibold ${danger?"border border-red-500/30 text-red-400":secondary?"border border-white/10 text-zinc-300":"bg-emerald-500 text-zinc-950"}`}>{text}</button>}
function money(v:number){return new Intl.NumberFormat("pt-BR",{style:"currency",currency:"BRL"}).format(v||0)}
function today(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,"0")}-${String(d.getDate()).padStart(2,"0")}`}
