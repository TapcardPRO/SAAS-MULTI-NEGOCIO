import { ReactNode } from "react";
import { cookies } from "next/headers";
import { redirect } from "next/navigation";
import { ObjectId } from "mongodb";
import Link from "next/link";
import { getDb } from "@/lib/db";
import { verifySessionToken } from "@/lib/auth";

export default async function DashboardLayout({ children }: { children: ReactNode }) {
  const cookieStore = await cookies();
  const token = cookieStore.get("saas_session")?.value;
  if (!token) redirect("/login");
  const session = await verifySessionToken(token);
  if (!session?.userId || !ObjectId.isValid(session.userId)) redirect("/login");
  const db = await getDb();
  const user = await db.collection("users").findOne({ _id: new ObjectId(session.userId) });
  if (!user) redirect("/login");
  if (user.role === "superadmin") redirect("/admin");
  if (user.active === false || !user.businessId || !ObjectId.isValid(String(user.businessId))) redirect("/login?blocked=1");
  const business = await db.collection("businesses").findOne({ _id: new ObjectId(String(user.businessId)) });
  if (!business || business.active === false) redirect("/login?blocked=1");

  return <><header className="sticky top-0 z-50 border-b border-white/10 bg-zinc-950/95 text-white backdrop-blur"><div className="mx-auto flex max-w-7xl items-center gap-3 overflow-x-auto px-6 py-3"><Link href="/dashboard/agenda" className="whitespace-nowrap rounded-lg px-3 py-2 text-sm hover:bg-white/5">Agenda</Link><Link href="/dashboard/clientes" className="whitespace-nowrap rounded-lg px-3 py-2 text-sm hover:bg-white/5">Clientes</Link><Link href="/dashboard/horarios" className="whitespace-nowrap rounded-lg px-3 py-2 text-sm hover:bg-white/5">Horários</Link><Link href="/dashboard/minha-pagina" className="whitespace-nowrap rounded-lg px-3 py-2 text-sm hover:bg-white/5">Minha página</Link><a href={`/${business.slug}`} target="_blank" rel="noreferrer" className="ml-auto whitespace-nowrap rounded-lg border border-white/10 px-3 py-2 text-sm">Ver página</a></div></header>{children}</>;
}
