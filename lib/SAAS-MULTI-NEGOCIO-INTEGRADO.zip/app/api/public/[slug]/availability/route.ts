import { NextResponse } from "next/server";
import { ObjectId } from "mongodb";
import { getDb } from "@/lib/db";
import { computeAvailability, getEligibleProfessionals } from "@/lib/booking";

type Props = { params: Promise<{ slug: string }> };

export async function GET(request: Request, { params }: Props) {
  try {
    const { slug } = await params;
    const url = new URL(request.url);
    const serviceId = url.searchParams.get("serviceId");
    const professionalId = url.searchParams.get("professionalId");
    const date = url.searchParams.get("date");

    if (!serviceId || !ObjectId.isValid(serviceId) || !date) {
      return NextResponse.json({ ok: false, message: "Parâmetros inválidos" }, { status: 400 });
    }

    const db = await getDb();
    const business = await db.collection("businesses").findOne({ slug, active: { $ne: false } });
    if (!business) return NextResponse.json({ ok: false, message: "Empresa não encontrada" }, { status: 404 });

    const service = await db.collection("services").findOne({ _id: new ObjectId(serviceId), active: { $ne: false } });
    if (!service) return NextResponse.json({ ok: false, message: "Serviço não encontrado" }, { status: 404 });

    if (professionalId && professionalId !== "any") {
      if (!ObjectId.isValid(professionalId)) return NextResponse.json({ ok: false, message: "Profissional inválido" }, { status: 400 });
      const result = await computeAvailability(db, {
        businessId: business._id,
        professionalId: new ObjectId(professionalId),
        serviceId: new ObjectId(serviceId),
        date,
      });
      return NextResponse.json({ ok: true, ...result, professionalId });
    }

    const professionals = await getEligibleProfessionals(db, business._id, new ObjectId(serviceId));
    const merged = new Set<string>();
    const byProfessional: Record<string, string[]> = {};

    for (const professional of professionals) {
      const result = await computeAvailability(db, {
        businessId: business._id,
        professionalId: professional._id,
        serviceId: new ObjectId(serviceId),
        date,
      });
      const id = professional._id.toString();
      byProfessional[id] = result.slots;
      result.slots.forEach((slot) => merged.add(slot));
    }

    return NextResponse.json({ ok: true, slots: Array.from(merged).sort(), byProfessional, duration: Number(service.duration || 30) });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ ok: false, message: "Erro ao calcular horários" }, { status: 500 });
  }
}
