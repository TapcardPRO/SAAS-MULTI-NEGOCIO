import { NextResponse } from "next/server";
import { ObjectId } from "mongodb";
import { requireBusinessSession } from "@/lib/tenant-auth";

type Props = { params: Promise<{ id: string }> };
const allowed = ["pendente", "confirmado", "em_atendimento", "concluido", "cancelado", "faltou"];

export async function PUT(request: Request, { params }: Props) {
  try {
    const auth = await requireBusinessSession();
    if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });
    const { id } = await params;
    if (!ObjectId.isValid(id)) return NextResponse.json({ ok: false, message: "Agendamento inválido" }, { status: 400 });
    const body = await request.json();
    const status = String(body.status || "");
    if (!allowed.includes(status)) return NextResponse.json({ ok: false, message: "Status inválido" }, { status: 400 });
    const appointment = await auth.db.collection("appointments").findOne({ _id: new ObjectId(id), businessId: auth.businessId });
    if (!appointment) return NextResponse.json({ ok: false, message: "Agendamento não encontrado" }, { status: 404 });
    const now = new Date();
    await auth.db.collection("appointments").updateOne({ _id: appointment._id, businessId: auth.businessId }, { $set: { status, updatedAt: now, ...(status === "concluido" ? { completedAt: now } : {}) } });
    if (status === "concluido" && appointment.clientId) {
      const alreadyCounted = appointment.countedInClient === true;
      if (!alreadyCounted) {
        await auth.db.collection("clients").updateOne({ _id: appointment.clientId, businessId: auth.businessId }, { $inc: { visitsCount: 1, totalSpent: Number(appointment.price || 0) }, $set: { lastVisit: appointment.date, updatedAt: now } });
        await auth.db.collection("appointments").updateOne({ _id: appointment._id }, { $set: { countedInClient: true } });
      }
    }
    return NextResponse.json({ ok: true, message: "Agendamento atualizado" });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ ok: false, message: "Erro ao atualizar agendamento" }, { status: 500 });
  }
}
