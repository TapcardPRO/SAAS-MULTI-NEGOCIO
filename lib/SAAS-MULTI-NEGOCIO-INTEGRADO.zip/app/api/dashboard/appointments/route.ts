import { NextResponse } from "next/server";
import { ObjectId } from "mongodb";
import { requireBusinessSession } from "@/lib/tenant-auth";
import { computeAvailability, normalizePhone, toMinutes } from "@/lib/booking";

export async function GET(request: Request) {
  try {
    const auth = await requireBusinessSession();
    if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });
    const url = new URL(request.url);
    const date = url.searchParams.get("date");
    const status = url.searchParams.get("status");
    const query: Record<string, any> = { businessId: auth.businessId };
    if (date) query.date = date;
    if (status) query.status = status;
    const appointments = await auth.db.collection("appointments").find(query).sort({ date: 1, startMinutes: 1, createdAt: 1 }).toArray();
    return NextResponse.json({ ok: true, appointments: appointments.map((a) => ({ ...a, _id: a._id.toString(), businessId: String(a.businessId), clientId: String(a.clientId), serviceId: String(a.serviceId), professionalId: String(a.professionalId) })) });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ ok: false, message: "Erro ao carregar agenda" }, { status: 500 });
  }
}

export async function POST(request: Request) {
  try {
    const auth = await requireBusinessSession();
    if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });
    const body = await request.json();
    const serviceId = String(body.serviceId || "");
    const professionalId = String(body.professionalId || "");
    const date = String(body.date || "");
    const time = String(body.time || "");
    const clientName = String(body.clientName || "").trim();
    const clientPhone = String(body.clientPhone || "").trim();
    if (!ObjectId.isValid(serviceId) || !ObjectId.isValid(professionalId) || !clientName || normalizePhone(clientPhone).length < 10 || !/^\d{4}-\d{2}-\d{2}$/.test(date) || !/^\d{2}:\d{2}$/.test(time)) return NextResponse.json({ ok: false, message: "Dados inválidos" }, { status: 400 });
    const service = await auth.db.collection("services").findOne({ _id: new ObjectId(serviceId) });
    const professional = await auth.db.collection("professionals").findOne({ _id: new ObjectId(professionalId) });
    if (!service || !professional) return NextResponse.json({ ok: false, message: "Serviço ou profissional inválido" }, { status: 404 });
    const availability = await computeAvailability(auth.db, { businessId: auth.businessId, professionalId: professional._id, serviceId: service._id, date });
    if (!availability.slots.includes(time)) return NextResponse.json({ ok: false, message: "Horário indisponível" }, { status: 409 });
    const phoneNorm = normalizePhone(clientPhone);
    let client = await auth.db.collection("clients").findOne({ businessId: auth.businessId, phoneNorm });
    const now = new Date();
    if (!client) {
      const r = await auth.db.collection("clients").insertOne({ businessId: auth.businessId, name: clientName, phone: clientPhone, phoneNorm, email: String(body.clientEmail || ""), active: true, visitsCount: 0, totalSpent: 0, createdAt: now, updatedAt: now });
      client = await auth.db.collection("clients").findOne({ _id: r.insertedId });
    }
    if (!client) throw new Error("Cliente não criado");
    const duration = Number(service.duration || 30); const startMinutes = toMinutes(time); const endMinutes = startMinutes + duration;
    const appointment = { businessId: auth.businessId, clientId: client._id, clientName, clientPhone, clientEmail: String(body.clientEmail || ""), serviceId: service._id, serviceName: service.name || "Serviço", price: Number(service.price || 0), duration, professionalId: professional._id, professionalName: professional.name || "Profissional", date, time, startMinutes, endMinutes, status: "confirmado", notes: String(body.notes || ""), source: "dashboard", createdAt: now, updatedAt: now };
    const r = await auth.db.collection("appointments").insertOne(appointment);
    return NextResponse.json({ ok: true, appointment: { id: r.insertedId.toString(), ...appointment } }, { status: 201 });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ ok: false, message: "Erro ao criar agendamento" }, { status: 500 });
  }
}
