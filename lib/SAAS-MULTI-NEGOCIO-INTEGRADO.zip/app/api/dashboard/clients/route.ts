import { NextResponse } from "next/server";
import { requireBusinessSession } from "@/lib/tenant-auth";

export async function GET() {
  try {
    const auth = await requireBusinessSession();
    if (!auth.ok) return NextResponse.json({ ok: false, message: auth.message }, { status: auth.status });
    const clients = await auth.db.collection("clients").find({ businessId: auth.businessId }).sort({ updatedAt: -1, createdAt: -1 }).toArray();
    return NextResponse.json({ ok: true, clients: clients.map((c) => ({ ...c, _id: c._id.toString(), businessId: String(c.businessId) })) });
  } catch (error) {
    console.error(error);
    return NextResponse.json({ ok: false, message: "Erro ao carregar clientes" }, { status: 500 });
  }
}
