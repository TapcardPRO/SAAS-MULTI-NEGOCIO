import { getDb } from "@/lib/db";
import { notFound } from "next/navigation";

type PageProps = {
  params: Promise<{
    slug: string;
  }>;
};

export default async function BusinessPage({ params }: PageProps) {
  const { slug } = await params;

const db = await getDb();

const business = await db.collection("businesses").findOne({
  slug,
});

if (!business) {
  notFound();
}
  const services = [
    {
      name: "Corte Tradicional",
      price: "R$ 35,00",
      duration: "40 min",
      photoUrl: "",
    },
    {
      name: "Barba",
      price: "R$ 25,00",
      duration: "30 min",
      photoUrl: "",
    },
    {
      name: "Corte + Barba",
      price: "R$ 55,00",
      duration: "60 min",
      photoUrl: "",
    },
  ];

  const professionals = [
    {
      name: "Igor Costa",
      role: "Profissional",
      photoUrl: "",
    },
    {
      name: "Carlos",
      role: "Profissional",
      photoUrl: "",
    },
    {
      name: "João",
      role: "Profissional",
      photoUrl: "",
    },
  ];

  return (
    <main
      className="min-h-screen"
      style={{
        backgroundColor: business.backgroundColor,
        color: business.textColor,
      }}
    >
      <section
        className="relative min-h-[620px] overflow-hidden border-b"
        style={{
          borderColor: `${business.primaryColor}30`,
          backgroundColor: business.secondaryColor,
        }}
      >
        {business.coverUrl ? (
          <img
            src={business.coverUrl}
            alt={`Capa de ${business.name}`}
            className="absolute inset-0 h-full w-full object-cover"
          />
        ) : null}

        <div
          className="absolute inset-0"
          style={{
            background: business.coverUrl
              ? `linear-gradient(to bottom, transparent, ${business.backgroundColor})`
              : `linear-gradient(to bottom, ${business.primaryColor}20, ${business.backgroundColor})`,
          }}
        />

        <div className="relative mx-auto flex min-h-[620px] max-w-6xl flex-col justify-end px-6 pb-16 pt-24">
          {business.logoUrl ? (
            <img
              src={business.logoUrl}
              alt={`Logo de ${business.name}`}
              className="mb-5 h-24 w-24 rounded-2xl border object-cover shadow-xl"
              style={{
                borderColor: `${business.primaryColor}40`,
              }}
            />
          ) : (
            <div
              className="mb-5 flex h-24 w-24 items-center justify-center rounded-2xl border text-3xl font-bold"
              style={{
                borderColor: `${business.primaryColor}40`,
                backgroundColor: `${business.primaryColor}20`,
                color: business.primaryColor,
              }}
            >
              {business.logoText}
            </div>
          )}

          <span
            className="mb-3 text-sm font-semibold uppercase tracking-widest"
            style={{
              color: business.primaryColor,
            }}
          >
            {business.category}
          </span>

          <h1 className="max-w-4xl text-4xl font-bold sm:text-6xl">
            {business.name}
          </h1>

          <p className="mt-5 max-w-2xl text-lg leading-8 opacity-75">
            {business.description}
          </p>

          <div className="mt-8 flex flex-wrap gap-3">
            <a
              href="#agendamento"
              className="rounded-xl px-6 py-3 font-semibold transition hover:opacity-90"
              style={{
                backgroundColor: business.primaryColor,
                color: business.backgroundColor,
              }}
            >
              Agendar agora
            </a>

            <a
              href={`https://wa.me/${business.whatsapp.replace(/\D/g, "")}`}
              target="_blank"
              rel="noreferrer"
              className="rounded-xl border px-6 py-3 font-semibold transition hover:opacity-80"
              style={{
                borderColor: `${business.textColor}30`,
              }}
            >
              WhatsApp
            </a>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <div className="grid gap-10 lg:grid-cols-2">
          <div>
            <span
              className="text-sm font-semibold uppercase tracking-widest"
              style={{
                color: business.primaryColor,
              }}
            >
              Sobre
            </span>

            <h2 className="mt-3 text-3xl font-bold">Sobre nós</h2>

            <p className="mt-5 leading-8 opacity-70">
              {business.description}
            </p>
          </div>

          <div
            className="rounded-2xl border p-6"
            style={{
              borderColor: `${business.textColor}15`,
              backgroundColor: `${business.textColor}08`,
            }}
          >
            <p className="text-sm opacity-50">Instagram</p>
            <p className="mt-1 font-medium">{business.instagram}</p>

            <p className="mt-5 text-sm opacity-50">WhatsApp</p>
            <p className="mt-1 font-medium">{business.whatsapp}</p>

            <p className="mt-5 text-sm opacity-50">Endereço</p>
            <p className="mt-1 font-medium">{business.address}</p>
          </div>
        </div>
      </section>

      <section
        className="border-y"
        style={{
          borderColor: `${business.textColor}10`,
          backgroundColor: business.secondaryColor,
        }}
      >
        <div className="mx-auto max-w-6xl px-6 py-16">
          <span
            className="text-sm font-semibold uppercase tracking-widest"
            style={{
              color: business.primaryColor,
            }}
          >
            Serviços
          </span>

          <h2 className="mt-3 text-3xl font-bold">Escolha seu serviço</h2>

          <div className="mt-8 grid gap-4 md:grid-cols-3">
            {services.map((service) => (
              <div
                key={service.name}
                className="overflow-hidden rounded-2xl border"
                style={{
                  borderColor: `${business.textColor}15`,
                  backgroundColor: business.backgroundColor,
                }}
              >
                {service.photoUrl ? (
                  <img
                    src={service.photoUrl}
                    alt={service.name}
                    className="h-44 w-full object-cover"
                  />
                ) : (
                  <div
                    className="h-44 w-full"
                    style={{
                      background: `linear-gradient(135deg, ${business.primaryColor}25, ${business.secondaryColor})`,
                    }}
                  />
                )}

                <div className="p-6">
                  <h3 className="text-lg font-semibold">{service.name}</h3>

                  <p className="mt-2 text-sm opacity-50">
                    {service.duration}
                  </p>

                  <p
                    className="mt-5 text-xl font-bold"
                    style={{
                      color: business.primaryColor,
                    }}
                  >
                    {service.price}
                  </p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-16">
        <span
          className="text-sm font-semibold uppercase tracking-widest"
          style={{
            color: business.primaryColor,
          }}
        >
          Equipe
        </span>

        <h2 className="mt-3 text-3xl font-bold">
          Conheça nossos profissionais
        </h2>

        <div className="mt-8 grid gap-4 sm:grid-cols-2 md:grid-cols-3">
          {professionals.map((professional) => (
            <div
              key={professional.name}
              className="rounded-2xl border p-6"
              style={{
                borderColor: `${business.textColor}15`,
                backgroundColor: `${business.textColor}08`,
              }}
            >
              {professional.photoUrl ? (
                <img
                  src={professional.photoUrl}
                  alt={professional.name}
                  className="mb-5 h-20 w-20 rounded-full object-cover"
                />
              ) : (
                <div
                  className="mb-5 flex h-20 w-20 items-center justify-center rounded-full text-xl font-bold"
                  style={{
                    backgroundColor: `${business.primaryColor}20`,
                    color: business.primaryColor,
                  }}
                >
                  {professional.name.charAt(0)}
                </div>
              )}

              <h3 className="font-semibold">{professional.name}</h3>

              <p className="mt-1 text-sm opacity-50">
                {professional.role}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section
        className="border-t"
        style={{
          borderColor: `${business.textColor}10`,
          backgroundColor: business.secondaryColor,
        }}
      >
        <div className="mx-auto max-w-6xl px-6 py-16">
          <span
            className="text-sm font-semibold uppercase tracking-widest"
            style={{
              color: business.primaryColor,
            }}
          >
            Galeria
          </span>

          <h2 className="mt-3 text-3xl font-bold">Conheça nosso espaço</h2>

         {business.gallery.length > 0 ? (
  <div className="mt-8 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
    {business.gallery.map((photo: string, index: number) => (
      <img
        key={`${photo}-${index}`}
        src={photo}
        alt={`Foto ${index + 1} de ${business.name}`}
        className="h-64 w-full rounded-2xl object-cover"
      />
    ))}
  </div>
) : (
  <div
    className="mt-8 flex min-h-48 items-center justify-center rounded-2xl border border-dashed px-6 text-center opacity-50"
    style={{
      borderColor: `${business.textColor}25`,
    }}
  >
    As fotos da galeria aparecerão aqui.
  </div>
)}
        </div>
      </section>

      <section
        id="agendamento"
        className="border-t"
        style={{
          borderColor: `${business.textColor}10`,
          backgroundColor: business.backgroundColor,
        }}
      >
        <div className="mx-auto max-w-6xl px-6 py-20 text-center">
          <span
            className="text-sm font-semibold uppercase tracking-widest"
            style={{
              color: business.primaryColor,
            }}
          >
            Agendamento
          </span>

          <h2 className="mt-3 text-3xl font-bold">
            Reserve seu horário
          </h2>

          <p className="mx-auto mt-4 max-w-xl opacity-60">
            Escolha serviço, profissional, data e horário de forma rápida.
          </p>

          <button
            className="mt-8 rounded-xl px-7 py-3 font-semibold transition hover:opacity-90"
            style={{
              backgroundColor: business.primaryColor,
              color: business.backgroundColor,
            }}
          >
            Escolher horário
          </button>
        </div>
      </section>

      <footer
        className="border-t py-8 text-center text-sm opacity-40"
        style={{
          borderColor: `${business.textColor}10`,
        }}
      >
        Página de {business.name} • {slug}
      </footer>
    </main>
  );
}