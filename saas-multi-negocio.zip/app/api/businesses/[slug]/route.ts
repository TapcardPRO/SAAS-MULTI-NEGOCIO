import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";

type RouteProps = {
  params: Promise<{
    slug: string;
  }>;
};

export async function GET(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;
    const db = await getDb();

    const business = await db
      .collection("businesses")
      .findOne({ slug });

    if (!business) {
      return NextResponse.json(
        {
          ok: false,
          message: "Negócio não encontrado",
        },
        { status: 404 }
      );
    }

    return NextResponse.json({
      ok: true,
      business,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        ok: false,
        message: "Erro ao buscar negócio",
      },
      { status: 500 }
    );
  }
}

export async function PUT(
  request: Request,
  { params }: RouteProps
) {
  try {
    const { slug } = await params;
    const body = await request.json();

    const db = await getDb();

    const updateData: Record<string, unknown> = {
      updatedAt: new Date(),
    };

    const allowedFields = [
      "name",
      "category",
      "description",
      "whatsapp",
      "instagram",
      "address",
      "primaryColor",
      "secondaryColor",
      "backgroundColor",
      "textColor",
      "logoUrl",
      "coverUrl",
      "gallery",
    ];

    for (const field of allowedFields) {
      if (body[field] !== undefined) {
        updateData[field] = body[field];
      }
    }

    const result = await db
      .collection("businesses")
      .updateOne(
        { slug },
        {
          $set: updateData,
        }
      );

    if (result.matchedCount === 0) {
      return NextResponse.json(
        {
          ok: false,
          message: "Negócio não encontrado",
        },
        { status: 404 }
      );
    }

    const business = await db
      .collection("businesses")
      .findOne({ slug });

    return NextResponse.json({
      ok: true,
      message: "Página atualizada com sucesso",
      business,
    });
  } catch (error) {
    console.error(error);

    return NextResponse.json(
      {
        ok: false,
        message: "Erro ao atualizar negócio",
      },
      { status: 500 }
    );
  }
}