"use client";

import { FormEvent, useEffect, useState } from "react";

type BusinessForm = {
  name: string;
  category: string;
  description: string;
  whatsapp: string;
  instagram: string;
  address: string;

  primaryColor: string;
  secondaryColor: string;
  backgroundColor: string;
  textColor: string;

  logoUrl: string;
  coverUrl: string;
  gallery: string[];
};

const SLUG = "engenheiros-do-corte";

const initialForm: BusinessForm = {
  name: "",
  category: "",
  description: "",
  whatsapp: "",
  instagram: "",
  address: "",

  primaryColor: "#22c55e",
  secondaryColor: "#18181b",
  backgroundColor: "#09090b",
  textColor: "#ffffff",

  logoUrl: "",
  coverUrl: "",
  gallery: [],
};

export default function MinhaPagina() {
  const [form, setForm] = useState<BusinessForm>(initialForm);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [message, setMessage] = useState("");

  useEffect(() => {
    async function loadBusiness() {
      try {
        const response = await fetch(`/api/businesses/${SLUG}`);
        const data = await response.json();

        if (!response.ok) {
          setMessage(data.message || "Erro ao carregar negócio");
          return;
        }

        setForm({
          name: data.business.name || "",
          category: data.business.category || "",
          description: data.business.description || "",
          whatsapp: data.business.whatsapp || "",
          instagram: data.business.instagram || "",
          address: data.business.address || "",

          primaryColor: data.business.primaryColor || "#22c55e",
          secondaryColor: data.business.secondaryColor || "#18181b",
          backgroundColor: data.business.backgroundColor || "#09090b",
          textColor: data.business.textColor || "#ffffff",

          logoUrl: data.business.logoUrl || "",
          coverUrl: data.business.coverUrl || "",
          gallery: data.business.gallery || [],
        });
      } catch {
        setMessage("Erro ao carregar os dados");
      } finally {
        setLoading(false);
      }
    }

    loadBusiness();
  }, []);

  function changeField<K extends keyof BusinessForm>(
    field: K,
    value: BusinessForm[K]
  ) {
    setForm((current) => ({
      ...current,
      [field]: value,
    }));
  }

  async function save(event: FormEvent) {
    event.preventDefault();

    setSaving(true);
    setMessage("");

    try {
      const response = await fetch(`/api/businesses/${SLUG}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(form),
      });

      const data = await response.json();

      if (!response.ok) {
        setMessage(data.message || "Erro ao salvar");
        return;
      }

      setMessage("Página atualizada com sucesso!");
    } catch {
      setMessage("Erro ao salvar alterações");
    } finally {
      setSaving(false);
    }
  }

  if (loading) {
    return (
      <main className="min-h-screen bg-zinc-950 p-8 text-white">
        Carregando...
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-zinc-950 text-white">
      <div className="mx-auto max-w-7xl px-6 py-10">
        <div className="mb-10">
          <p className="text-sm font-semibold uppercase tracking-widest text-emerald-400">
            Personalização
          </p>

          <h1 className="mt-2 text-3xl font-bold">Minha página</h1>

          <p className="mt-2 text-zinc-400">
            Personalize as informações e o visual da sua página pública.
          </p>
        </div>

        <div className="grid gap-8 lg:grid-cols-2">
          <form
            onSubmit={save}
            className="space-y-6 rounded-2xl border border-white/10 bg-white/5 p-6"
          >
            <div>
              <h2 className="text-xl font-semibold">Informações</h2>
              <p className="mt-1 text-sm text-zinc-500">
                Dados exibidos para seus clientes.
              </p>
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Nome do negócio
              </label>

              <input
                value={form.name}
                onChange={(e) => changeField("name", e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Categoria
              </label>

              <input
                value={form.category}
                onChange={(e) => changeField("category", e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
              />
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Sobre o negócio
              </label>

              <textarea
                value={form.description}
                onChange={(e) => changeField("description", e.target.value)}
                rows={5}
                className="w-full resize-none rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
              />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <label className="mb-2 block text-sm text-zinc-400">
                  WhatsApp
                </label>

                <input
                  value={form.whatsapp}
                  onChange={(e) => changeField("whatsapp", e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
                />
              </div>

              <div>
                <label className="mb-2 block text-sm text-zinc-400">
                  Instagram
                </label>

                <input
                  value={form.instagram}
                  onChange={(e) => changeField("instagram", e.target.value)}
                  className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
                />
              </div>
            </div>

            <div>
              <label className="mb-2 block text-sm text-zinc-400">
                Endereço
              </label>

              <input
                value={form.address}
                onChange={(e) => changeField("address", e.target.value)}
                className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
              />
            </div>

            <div className="border-t border-white/10 pt-6">
              <h2 className="text-xl font-semibold">Cores</h2>

              <p className="mt-1 text-sm text-zinc-500">
                Escolha a identidade visual da sua página.
              </p>

              <div className="mt-5 grid gap-4 sm:grid-cols-2">
                <ColorField
                  label="Cor principal"
                  value={form.primaryColor}
                  onChange={(value) => changeField("primaryColor", value)}
                />

                <ColorField
                  label="Cor secundária"
                  value={form.secondaryColor}
                  onChange={(value) => changeField("secondaryColor", value)}
                />

                <ColorField
                  label="Cor do fundo"
                  value={form.backgroundColor}
                  onChange={(value) => changeField("backgroundColor", value)}
                />

                <ColorField
                  label="Cor do texto"
                  value={form.textColor}
                  onChange={(value) => changeField("textColor", value)}
                />
              </div>
            </div>

            <div className="border-t border-white/10 pt-6">
              <h2 className="text-xl font-semibold">Imagens</h2>

              <p className="mt-1 text-sm text-zinc-500">
                Nesta primeira etapa vamos usar URLs. Depois vamos colocar
                upload direto de fotos.
              </p>

              <div className="mt-5 space-y-4">
                <div>
                  <label className="mb-2 block text-sm text-zinc-400">
                    URL da logo
                  </label>

                  <input
                    value={form.logoUrl}
                    onChange={(e) => changeField("logoUrl", e.target.value)}
                    placeholder="https://..."
                    className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
                  />
                </div>

                <div>
                  <label className="mb-2 block text-sm text-zinc-400">
                    URL da foto de capa
                  </label>

                  <input
                    value={form.coverUrl}
                    onChange={(e) => changeField("coverUrl", e.target.value)}
                    placeholder="https://..."
                    className="w-full rounded-xl border border-white/10 bg-zinc-900 px-4 py-3 outline-none focus:border-emerald-500"
                  />
                </div>
              </div>
            </div>

            {message ? (
              <div className="rounded-xl bg-white/5 p-4 text-sm">
                {message}
              </div>
            ) : null}

            <button
              type="submit"
              disabled={saving}
              className="w-full rounded-xl bg-emerald-500 px-6 py-3 font-semibold text-zinc-950 transition hover:bg-emerald-400 disabled:opacity-50"
            >
              {saving ? "Salvando..." : "Salvar alterações"}
            </button>
          </form>

          <div className="lg:sticky lg:top-6 lg:h-fit">
            <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-zinc-500">
              Prévia
            </p>

            <div
              className="overflow-hidden rounded-3xl border shadow-2xl"
              style={{
                backgroundColor: form.backgroundColor,
                color: form.textColor,
                borderColor: `${form.textColor}20`,
              }}
            >
              <div
                className="relative min-h-80 p-8"
                style={{
                  backgroundColor: form.secondaryColor,
                }}
              >
                {form.coverUrl ? (
                  <img
                    src={form.coverUrl}
                    alt=""
                    className="absolute inset-0 h-full w-full object-cover"
                  />
                ) : null}

                <div
                  className="absolute inset-0"
                  style={{
                    background: form.coverUrl
                      ? `linear-gradient(to bottom, transparent, ${form.backgroundColor})`
                      : `linear-gradient(135deg, ${form.primaryColor}25, ${form.backgroundColor})`,
                  }}
                />

                <div className="relative">
                  {form.logoUrl ? (
                    <img
                      src={form.logoUrl}
                      alt=""
                      className="mb-6 h-20 w-20 rounded-2xl object-cover"
                    />
                  ) : (
                    <div
                      className="mb-6 flex h-20 w-20 items-center justify-center rounded-2xl text-2xl font-bold"
                      style={{
                        backgroundColor: `${form.primaryColor}25`,
                        color: form.primaryColor,
                      }}
                    >
                      {form.name
                        ? form.name
                            .split(" ")
                            .slice(0, 2)
                            .map((word) => word.charAt(0))
                            .join("")
                            .toUpperCase()
                        : "S"}
                    </div>
                  )}

                  <p
                    className="text-xs font-bold uppercase tracking-widest"
                    style={{
                      color: form.primaryColor,
                    }}
                  >
                    {form.category || "Categoria"}
                  </p>

                  <h2 className="mt-3 text-3xl font-bold">
                    {form.name || "Nome do negócio"}
                  </h2>

                  <p className="mt-4 max-w-lg text-sm leading-6 opacity-70">
                    {form.description ||
                      "A descrição do seu negócio aparecerá aqui."}
                  </p>

                  <button
                    type="button"
                    className="mt-6 rounded-xl px-5 py-3 font-semibold"
                    style={{
                      backgroundColor: form.primaryColor,
                      color: form.backgroundColor,
                    }}
                  >
                    Agendar agora
                  </button>
                </div>
              </div>

              <div className="p-8">
                <p className="text-sm opacity-50">WhatsApp</p>
                <p className="mt-1">{form.whatsapp || "-"}</p>

                <p className="mt-5 text-sm opacity-50">Instagram</p>
                <p className="mt-1">{form.instagram || "-"}</p>

                <p className="mt-5 text-sm opacity-50">Endereço</p>
                <p className="mt-1">{form.address || "-"}</p>
              </div>
            </div>

            <a
              href={`/${SLUG}`}
              target="_blank"
              className="mt-4 block text-center text-sm font-medium text-emerald-400 hover:underline"
            >
              Abrir página pública
            </a>
          </div>
        </div>
      </div>
    </main>
  );
}

function ColorField({
  label,
  value,
  onChange,
}: {
  label: string;
  value: string;
  onChange: (value: string) => void;
}) {
  return (
    <div>
      <label className="mb-2 block text-sm text-zinc-400">{label}</label>

      <div className="flex gap-3">
        <input
          type="color"
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="h-12 w-14 cursor-pointer rounded-lg border border-white/10 bg-transparent p-1"
        />

        <input
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="min-w-0 flex-1 rounded-xl border border-white/10 bg-zinc-900 px-3 py-3 font-mono text-sm outline-none focus:border-emerald-500"
        />
      </div>
    </div>
  );
}